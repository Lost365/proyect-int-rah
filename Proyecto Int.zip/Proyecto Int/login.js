function guardarCredenciales(usuario, clave) {
    localStorage.setItem('usuario', usuario)
    localStorage.setItem('clave', clave)
}

function obtenerCredenciales() {
    return {
        usuario: localStorage.getItem('usuario'),
        clave: localStorage.getItem('clave')
    }
}

function verificarLogin() {
    const usuarioIngresado = document.getElementById('usuario').value
    const claveIngresada = document.getElementById('clave').value
    const { usuario, clave } = obtenerCredenciales()

    const mensaje = document.getElementById('mensaje')
    let intentos = parseInt(localStorage.getItem('intentos')) || 0
    const MAX_INTENTOS = 3

    if (usuarioIngresado === usuario && claveIngresada === clave) {
    mensaje.textContent = '¡Bienvenido!'
    mensaje.className = ''
    mensaje.style.color = '#1e3c72'
    mensaje.style.textAlign = 'center'
        document.querySelector('button').disabled = true
        localStorage.setItem('intentos', 0)
    } else {
        intentos++
        localStorage.setItem('intentos', intentos)

        if (intentos >= MAX_INTENTOS) {
            mensaje.textContent = 'Usuario bloqueado por demasiados intentos.'
            mensaje.className = 'error'
            document.querySelector('button').disabled = true
            document.getElementById('usuario').disabled = true
            document.getElementById('clave').disabled = true
        } else {
            mensaje.textContent = `Error: te quedan ${MAX_INTENTOS - intentos} intentos.`
            mensaje.className = 'error'
        }
    }
}

function registrarUsuario() {
    const nuevoUsuario = document.getElementById('registroUsuario').value
    const nuevaClave = document.getElementById('registroClave').value
    const mensaje = document.getElementById('mensaje')

    if (nuevoUsuario && nuevaClave) {
        guardarCredenciales(nuevoUsuario, nuevaClave)
        mensaje.textContent = 'Registro exitoso. Ahora puedes iniciar sesión.'
        mensaje.className = ''
        document.getElementById('registroUsuario').value = ''
        document.getElementById('registroClave').value = ''
    } else {
        mensaje.textContent = 'Por favor, completa ambos campos.'
        mensaje.className = 'error'
    }
}

function cambiarCredenciales() {
    const nuevoUsuario = document.getElementById('nuevoUsuario').value
    const nuevaClave = document.getElementById('nuevaClave').value
    const mensaje = document.getElementById('mensaje')

    if (nuevoUsuario && nuevaClave) {
        guardarCredenciales(nuevoUsuario, nuevaClave)
        mensaje.textContent = 'Credenciales actualizadas. Vuelve al login.'
        mensaje.className = ''
        document.getElementById('nuevoUsuario').value = ''
        document.getElementById('nuevaClave').value = ''
        localStorage.setItem('intentos', 0)
    } else {
        mensaje.textContent = 'Por favor, completa ambos campos.'
        mensaje.className = 'error'
    }
}