let usuarioRegistrado = 'admin'
let claveRegistrada = 'jaja'
let intentos = 0
const MAX_INTENTOS = 3

function registrarUsuario() {
    const nuevoUsuario = document.getElementById('registroUsuario').value
    const nuevaClave = document.getElementById('registroClave').value
    const mensaje = document.getElementById('mensaje')

    if (nuevoUsuario && nuevaClave) {
        usuarioRegistrado = nuevoUsuario
        claveRegistrada = nuevaClave
        mensaje.textContent = 'Registro exitoso. Ahora puedes iniciar sesión.'
        mensaje.className = ''
    } else {
        mensaje.textContent = 'Por favor, completa ambos campos.'
        mensaje.className = 'error'
    }
}

function verificarLogin() {
    const usuarioIngresado = document.getElementById('usuario').value
    const claveIngresada = document.getElementById('clave').value
    const mensaje = document.getElementById('mensaje')

    if (usuarioRegistrado === '' || claveRegistrada === '') {
        mensaje.textContent = 'No hay usuario registrado.'
        mensaje.className = 'error'
        return
    }

    if (usuarioIngresado === usuarioRegistrado && claveIngresada === claveRegistrada) {
        mensaje.textContent = '¡Bienvenido!'
    mensaje.className = ""
    mensaje.style.color = '#1e3c72' 
    mensaje.style.textAlign = 'center'
        intentos = 0
    } else {
        intentos++
        if (intentos >= MAX_INTENTOS) {
            mensaje.textContent = 'Usuario bloqueado por demasiados intentos.'
            mensaje.className = 'error'
            document.getElementById('usuario').disabled = true
            document.getElementById('clave').disabled = true
            document.querySelector('button').disabled = true
        } else {
            mensaje.textContent = `Error: te quedan ${MAX_INTENTOS - intentos} intentos.`
            mensaje.className = 'error'
        }
    }
}

function cambiarCredenciales() {
    const nuevoUsuario = document.getElementById('nuevoUsuario').value
    const nuevaClave = document.getElementById('nuevaClave').value
    const mensaje = document.getElementById('mensaje')

    if (nuevoUsuario && nuevaClave) {
        usuarioRegistrado = nuevoUsuario
        claveRegistrada = nuevaClave
        intentos = 0
        mensaje.textContent = 'Credenciales actualizadas. Vuelve al login.'
        mensaje.className = ''
    } else {
        mensaje.textContent = 'Por favor, completa ambos campos.'
        mensaje.className = 'error'
    }
}